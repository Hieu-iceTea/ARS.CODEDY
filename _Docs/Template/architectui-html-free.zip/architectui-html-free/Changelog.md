### Changelog

## Version 1.0.0 (17 January 2019)